<?php
require_once 'navbar.php';
require_once 'form.php';
require_once 'server.php';
require_once 'view.php';